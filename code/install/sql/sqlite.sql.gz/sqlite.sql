PRAGMA cache_size=2000;
PRAGMA synchronous=OFF;
PRAGMA count_changes=OFF;
PRAGMA foreign_keys=OFF;
